package com.springboot.elearning.myapp.service;


import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.elearning.myapp.dao.CourseCategoryRepository;
import com.springboot.elearning.myapp.entity.CourseCategory;



@Service
public class CourseCategoryService {
	@Autowired
	private CourseCategoryRepository categoryrepo;
	
	public List<CourseCategory> getAllCategories()
	{
		List<CourseCategory> categories=new ArrayList<>();
		categoryrepo.findAll()
		.forEach(categories::add);
		return categories;
	}

	public Optional<CourseCategory> getCategory(Long id) {
		return categoryrepo.findById(id);
	}
	public void addCategory(CourseCategory co) {
		categoryrepo.save(co);
	}
	public void updateCategory(Long id,CourseCategory co) {
		categoryrepo.save(co);
	}
	public void deleteCategory(Long id) {
		categoryrepo.deleteById(id);
	}
}



