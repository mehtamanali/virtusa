package com.springboot.elearning.myapp.controller;
import java.util.Date;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.elearning.myapp.entity.Course;
import com.springboot.elearning.myapp.entity.CourseCategory;
import com.springboot.elearning.myapp.service.CourseService;



@RestController

public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@RequestMapping("category/course")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Course> getAllCourse()
	{
		return courseService.getAllCourse();
	}
	
	@RequestMapping("category/course/{id}")
	@CrossOrigin(origins = "http://localhost:4200")

	public Optional<Course>  getCourse(@PathVariable Long id) {
		return courseService.getCourse(id);
	}
	@RequestMapping(method=RequestMethod.POST,value="category/{categoryid}/course")
	@CrossOrigin(origins = "http://localhost:4200")
	public void addCourse(@RequestBody Course co,@PathVariable Long categoryid) {
		co.setCategory(new CourseCategory(categoryid,""));
		courseService.addCourse(co);
	}
	@RequestMapping(method=RequestMethod.PUT,value="category/{categoryid}/course/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public void updateCourse(@RequestBody Course co,@PathVariable Long categoryid,@PathVariable Long id) {
		co.setLastUpdate(new Date());
		co.setId(id);
		co.setCategory(new CourseCategory(categoryid,""));
		courseService.updateCourse(co);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="category/course/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public void deleteCourse(@PathVariable Long id) {
		courseService.deleteCourse(id);
	}
	
	
}
