package com.springboot.elearning.myapp.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.elearning.myapp.entity.CourseCategory;
import com.springboot.elearning.myapp.service.CourseCategoryService;




@RestController
public class CourseCategoryController {
	
	@Autowired
	private CourseCategoryService categoryService;
	
	@RequestMapping("/category")
	public List<CourseCategory> getAllCategories()
	{
		return categoryService.getAllCategories();
	}
	
	@RequestMapping("/category/{id}")
	public Optional<CourseCategory>  getCategory(@PathVariable Long id) {
		return categoryService.getCategory(id);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/category")
	public void addCategory(@RequestBody CourseCategory co) {
		categoryService.addCategory(co);
	}
	@RequestMapping(method=RequestMethod.PUT,value="/category/{id}")
	public void updateCategory(@RequestBody CourseCategory co,@PathVariable Long id) {
		categoryService.updateCategory(id,co);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/category/{id}")
	public void deleteCategory(@PathVariable Long id) {
		categoryService.deleteCategory(id);
	}
	
	
}
