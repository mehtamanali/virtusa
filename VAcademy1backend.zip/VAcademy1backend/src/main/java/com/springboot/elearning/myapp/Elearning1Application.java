package com.springboot.elearning.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Elearning1Application {

	public static void main(String[] args) {
		SpringApplication.run(Elearning1Application.class, args);
	}

}
