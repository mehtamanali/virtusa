import { Component, OnInit } from '@angular/core';
import { CourseCategory} from 'src/app/common/course-category';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-course-category-menu',
  templateUrl: './course-category-menu.component.html',
  styleUrls: ['./course-category-menu.component.css']
})
export class CourseCategoryMenuComponent implements OnInit {

  courseCategories: CourseCategory[];


  constructor(private courseService:CourseService) { }

  ngOnInit(): void {

    this.listCourseCategories();
    
  }


  listCourseCategories() {
    
    this.courseService.getCourseCategories().subscribe(

      data =>{
        console.log('Course Categories' + JSON.stringify(data));
        this.courseCategories=data;
      }
    );
  }

}
