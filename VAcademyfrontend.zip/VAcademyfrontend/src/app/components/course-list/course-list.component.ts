import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/services/course.service';
import { Course } from 'src/app/common/course';
import { ActivatedRoute } from '@angular/router';
import {CartItem} from 'src/app/common/cart-item';
import {CartService} from 'src/app/services/cart.service';
@Component({
  selector: 'app-course-list',
  //templateUrl: './course-list.component.html',
  templateUrl: './course-list-grid.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses:Course[]=[];
  currentCategoryId:number=1;
  searchMode:boolean=false;
//the pagination properties
  thePageNumber:number=1;
  thePageSize:number=10;
  theTotalElements:number=0;
  previousCategoryId: number=1;

//new properties for pagintion by search

previousKeyword:string=null;


  constructor(private courseService:CourseService,private cartService:CartService,
              private route:ActivatedRoute)
   { 

   }

  ngOnInit(){
    this.route.paramMap.subscribe(() => {
    this.listCourses();
  });
}
  listCourses()
  {
    this.searchMode=this.route.snapshot.paramMap.has('keyword');
    if(this.searchMode){
      this.handleSearchCourses();
    }
    else
    {
      this.handleListCourses();
    }
    
  }
  handleSearchCourses()
  {
    const theKeyword: string= this.route.snapshot.paramMap.get('keyword');

   
    //
    //
    //if we have different keyword than previous
    //then set the page number to 1
    if(this.previousKeyword!=theKeyword)
    {
      this.thePageNumber = 1;
    }

    this.previousKeyword=theKeyword;

    console.log(`keyword=${theKeyword}, thePageNumber=${this.thePageNumber}`);



     //now search for courses using keyword

    //this.courseService.searchCourses(theKeyword).subscribe(
    //  data =>{
      //  this.courses=data;
     // }
   // );

   //update method foe searchcourses using kryword for pagitation
   this.courseService.searchCoursesPaginate(this.thePageNumber -1,
                                              this.thePageSize,
                                              theKeyword).subscribe(this.processResult())

  }
  handleListCourses()
  {
    //check if 'id' parameter is available

    const hasCategoryId :boolean=this.route.snapshot.paramMap.has('id')

    if(hasCategoryId){
      //get the 'id' param string. convert string to a number using the '+' symbol
            this.currentCategoryId = +this.route.snapshot.paramMap.get('id');
    }
    else
    {
      //not category id available ... default to category 1
      this.currentCategoryId=1;
    }
    //
    //
    //check if we have different category than pervious
    //NOte:Angular will reuse a component if it is currently being viewed
    //
    //
    //if we have different category id than previous 
    //then set thePageNumber back to 1
    if(this.previousCategoryId !- this.currentCategoryId){
      this.thePageNumber=1;
    }
    this.previousCategoryId=this.currentCategoryId;
    console.log(`currentCategoryId=${this.currentCategoryId},thePageNumber=${this.thePageNumber}`);

    this.courseService.getCourseListPaginate(this.thePageNumber -1,
                                             this.thePageSize,
                                             this.currentCategoryId).subscribe(this.processResult());

    }





    //this is different code not pagitation ka so dony delete it later
//ye method without pagination ka hai apneko change karna hai baad me
    //now get the course for the given category id
    //this.courseService.getCourseList(this.currentCategoryId).subscribe(
     // data =>{
      //  this.courses=data;
     // }
    //)

  
  processResult() {
    return data=>{
      this.courses=data._embedded.courses;
      this.thePageNumber=data.page.number + 1;
      this.thePageSize=data.page.size;
      this.theTotalElements=data.page.totalElements;
    };
  }
    addToCart(theCourse:Course){

      console.log(`Adding to cart:${theCourse.name},${theCourse.unitPrice}`);
      //
      // TODO ... do the real work
    const theCartItem = new CartItem(theCourse);

    this.cartService.addToCart(theCartItem);

    }
  }
  

