import { Component, OnInit } from '@angular/core';
import { CourseCategory } from 'src/app/common/course-category';
import { Course } from 'src/app/common/course';
import { AdminService } from 'src/app/services/admin.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-update-courses',
  templateUrl: './update-courses.component.html',
  styleUrls: ['./update-courses.component.css']
})
export class UpdateCoursesComponent implements OnInit {

  category: CourseCategory[];
  courses = new Course();
   Course=new Course();
  selected: Number = 1;
  courseid : Course;
  constructor(private adminService: AdminService, private _courseservice: CourseService) { }

  ngOnInit(): void {
    this.listCourses();
    this.listCourseCategory();
  }

  listCourses(){
    this.courseid = this.adminService.get();
    console.log(this.courseid);
    this.adminService.getCourse(this.courseid).subscribe(
      data => {
        this.Course = data
        console.log(this.Course)
      }
     
    )
  }
  listCourseCategory() {
    this._courseservice.getCourseCategories().subscribe(
      data => this.category = data
    )
  }
  updateCourses() {
    this.adminService.updateCourse(this.courses,this.selected).subscribe(
      data => console.log("sucess"),
      error => console.log("exception")
    )
  }

}
