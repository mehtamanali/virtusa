import { Component, OnInit } from '@angular/core';
import { Course } from 'src/app/common/course';
import { CourseService } from 'src/app/services/course.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {

  course:Course =new Course();

  constructor(private courseService:CourseService,
              private route:ActivatedRoute) {

               }

  ngOnInit(): void {
    this.route.paramMap.subscribe(()=>
    {
      this.handleCourseDetails();
    })
  }
  handleCourseDetails() {
    //get the "id" parameter string. convert string to numberusing '+' symbol

    const theCourseId: number=+this.route.snapshot.paramMap.get('id');

    this.courseService.getCourse(theCourseId).subscribe(
      data =>{
        this.course =data;
      }
      );
  }

}
