import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from 'src/app/common/course';
import { AdminService } from 'src/app/services/admin.service';
@Component({
  selector: 'app-admin-interface',
  templateUrl: './admin-interface.component.html',
  styleUrls: ['./admin-interface.component.css']
})
export class AdminInterfaceComponent implements OnInit {

  courses: Course[] = [];

  constructor(private adminService: AdminService,
    private route:Router) { }

  ngOnInit(): void {
    this.listCourses();
  }
  listCourses(){
    this.adminService.getallCourses().subscribe(
      data => {
        this.courses=data;
        console.log(this.courses)
      }
     
    )
  }
  removeCourse(courseid : Course){
    this.adminService.removeCourse(courseid).subscribe(
      data => {
        console.log("success")
        window.location.reload();
      },
      error => console.log("error")
    );

  }
  update(courseid : Course){
    this.adminService.set(courseid);
    this.route.navigate(['/update']);
    
  }

}
