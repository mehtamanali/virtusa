import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { CourseService } from 'src/app/services/course.service';
import { CourseCategory } from 'src/app/common/course-category';
import { Course } from 'src/app/common/course';

@Component({
  selector: 'app-add-courses',
  templateUrl: './add-courses.component.html',
  styleUrls: ['./add-courses.component.css']
})
export class AddCoursesComponent implements OnInit {

  category: CourseCategory[];
  courses = new Course();
  selected: Number = 1;


  constructor(private adminService: AdminService, private _courseservice: CourseService) { }

  ngOnInit(): void {
    this.listCourseCategory();
  }
  addCourses() {
    this.adminService.addCourses(this.courses, this.selected).subscribe(
      data => console.log("sucess"),
      error => console.log("exception")
    )
  }

  listCourseCategory() {
    this._courseservice.getCourseCategories().subscribe(
      data => this.category = data
    )
  }


}
