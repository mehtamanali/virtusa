import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import {CourseListComponent} from './components/course-list/course-list.component';
import { SearchComponent } from './components/search/search.component';
import { CourseCategoryMenuComponent } from './components/course-category-menu/course-category-menu.component';
import { RouterModule, Routes } from '@angular/router';
import { CourseService } from './services/course.service';
import { CourseDetailsComponent } from './components/course-details/course-details.component';
import { CartStatusComponent } from './components/cart-status/cart-status.component';
import { CartDetailsComponent } from './components/cart-details/cart-details.component';
import { LoginComponent } from './components/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
//we need to remove
import { httpInterceptorProviders } from './auth/auth.interceptor';
import {RegisterComponent} from './components/register/register.component';
import { AdminInterfaceComponent } from './components/admin-interface/admin-interface.component';
import { AddCoursesComponent } from './components/add-courses/add-courses.component';
import { UpdateCoursesComponent } from './components/update-courses/update-courses.component';

const routes: Routes=[

  {path:'register' ,component:RegisterComponent},
  {path: 'admin' , component : AdminInterfaceComponent},
  {path:'login' ,component:LoginComponent},

  
 {path: 'update' , component : UpdateCoursesComponent},

  {path: 'addCourses' , component : AddCoursesComponent},
  {path: 'cart-details', component: CartDetailsComponent},
  {path:'courses/:id',component: CourseDetailsComponent},
  {path:'search/:keyword',component: CourseListComponent},
  {path:'category/:id',component:CourseListComponent},
  {path:'courses',component:CourseListComponent},
  {path:'category',component:CourseListComponent},
  
  {path:'',redirectTo:'/courses',pathMatch:'full'},
  {path:'**',redirectTo:'/courses',pathMatch:'full'}
  

];

@NgModule({
  declarations: [
    AppComponent,
    CourseListComponent,
    SearchComponent,
    CourseDetailsComponent,
    CourseCategoryMenuComponent,
    CartStatusComponent,
    CartDetailsComponent,
    LoginComponent,
    RegisterComponent,
    AdminInterfaceComponent,
    AddCoursesComponent,
    UpdateCoursesComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    RouterModule,
    SearchComponent,
    FormsModule
  ],
  providers: [CourseService,
    httpInterceptorProviders
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
