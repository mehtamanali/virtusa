import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import{Course} from '../common/course';
import {map} from 'rxjs/operators';
import { CourseCategory } from '../common/course-category';

@Injectable({
  providedIn: 'root'
})


export class CourseService {
  


  private baseUrl='http://localhost:8081/api/courses';

  private categoryUrl='http://localhost:8081/api/course-category';


  constructor(private httpClient:HttpClient) { }

  getCourse(theCourseId: number): Observable<Course> {
    //NEED to buld url based on course id

    const courseUrl=`${this.baseUrl}/${theCourseId}`;

    return this.httpClient.get<Course>(courseUrl);
  }

  getCourseList(theCategoryId:number): Observable<Course[]>{

    //need to build URL based on category Id
    const searchUrl = `${this.baseUrl}/search/findByCategoryId?id=${theCategoryId}`;
    
    return this.getCourses(searchUrl);
}
//the pagination method we can remove it later if not required
getCourseListPaginate(thePage:number,
                       thePageSize:number,
                       theCategoryId:number): Observable<GetResponseCourses>{

  //need to build URL based on category Id,page and size
  const searchUrl = `${this.baseUrl}/search/findByCategoryId?id=${theCategoryId}`
          +`&page=${thePage}&size=${thePageSize}`;
  
  return this.httpClient.get<GetResponseCourses>(searchUrl);
}
searchCourses(theKeyword: string): Observable<Course[]> {

   //need to build URL based on keyword
  const searchUrl = `${this.baseUrl}/search/findByNameContaining?name=${theKeyword}`;

  return this.getCourses(searchUrl);
  
}

//psearch pagination 
searchCoursesPaginate(thePage:number,
                       thePageSize:number,
                     theKeyword:string): Observable<GetResponseCourses>{

//need to build URL based on category Id,page and size
const searchUrl = `${this.baseUrl}/search/findByNameContaining?name=${theKeyword}`
                  +`&page=${thePage}&size=${thePageSize}`;

       return this.httpClient.get<GetResponseCourses>(searchUrl);
}


  private getCourses(searchUrl: string): Observable<Course[]> {
    return this.httpClient.get<GetResponseCourses>(searchUrl).pipe(
      map(response => response._embedded.courses)
    );
  }

getCourseCategories() :Observable<CourseCategory[]>
  {
    return this.httpClient.get<GetResponseCourseCategory>(this.categoryUrl).pipe(
      map(response => response._embedded.courseCategory)
    );
  }
}

interface GetResponseCourses {
  _embedded:{
    courses:Course[];
  },
  page:  {
    size:number,
    totalElements:number,
    totalPages:number,
    number:number
  }
}

interface GetResponseCourseCategory {
  _embedded:{
    courseCategory:CourseCategory[];
  }
}
