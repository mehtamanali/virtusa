import { Injectable } from '@angular/core';
import { Course } from '../common/course';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  courseid:Course;
  baseUrl="http://localhost:8081/category";
  coursesUrl="http://localhost:8081/category/course";
  
  constructor(private http : HttpClient) { }

  public set(courseId: Course) {
    this.courseid = courseId;
  }
  public get(){
    return this.courseid;
  }
  public addCourses(courses : Course,theCategoryId:Number):Observable<any>{
    const searchUrl  =`${this.baseUrl}/${theCategoryId}/course`;
   return  this.http.post<any>(searchUrl,courses);
  }
  public getCourse(clothid : Course):Observable<any>{
    const courseUrl = `${this.coursesUrl}/${this.courseid}`;
    return  this.http.get<any>(courseUrl);
   }
  public getallCourses():Observable<any>{
   return  this.http.get<any>(this.coursesUrl);
  }
  public removeCourse(courseid: Course):Observable<any> {
    const removeUrl  =`${this.coursesUrl}/${courseid}`;
    return this.http.delete<any>(removeUrl);
   
  }
  public updateCourse(courses: Course,theCategoryId:Number):Observable<any> {
    const courseId = this.courseid;
    const updateUrl  =`${this.baseUrl}/${theCategoryId}/course/${courseId}`;
    return this.http.put<any>(updateUrl,courses);
   
  }
}
