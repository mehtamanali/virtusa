import { CourseCategory } from './course-category';

describe('CourseCategory', () => {
  it('should create an instance', () => {
    expect(new CourseCategory()).toBeTruthy();
  });
});
