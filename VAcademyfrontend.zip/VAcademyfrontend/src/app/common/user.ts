export class User {
    id: number;
    emailId:String;
    username:String;
    password:String;
constructor(){}
}
  /*  constructor(  id: number,emailId:String,
        username:String,
        password:String){
            this.id = id;
            this.emailId = emailId;
            this.username = username;
            this.password = password;
        }*/

