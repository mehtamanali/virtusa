export class Course {
    name:string;
    description:string;
    unitPrice:number;
    imageUrl:string;
    dateCreated:Date;
    lastUpdated:Date;
    id: number;


}
