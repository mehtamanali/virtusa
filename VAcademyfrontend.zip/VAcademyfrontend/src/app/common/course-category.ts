export class CourseCategory {
    id:number;
    categoryName:string;
}
